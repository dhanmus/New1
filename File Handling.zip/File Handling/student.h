#include<iostream>
using namespace std;
class Student
{  
    private:
	  int rollno;
	  char name[30];
	  int p,c,m;
    public:
        void getStudent()
	    { 
		    cout<<"Enter Roll No. : ";
	        cin>>rollno;
	     	cout<<"Enter Name : ";
	        cin>>name;
	        cout<<"Enter Physics Marks : ";
	        cin>>p;
	        cout<<"Enter Chemistry Marks : ";
	        cin>>c;
	        cout<<"Enter Maths Marks : ";
	        cin>>m;
	    }	  
	
	    void putStudent()
      	{
	        cout<<rollno<<","<<name<<","<<p<<","<<c<<","<<m<<endl;
		}	
		
        int search(int rollno)
        { 
	        if(this->rollno==rollno)
            { 
	            putStudent();
                return 1;
	        }
	        return 0;
		}	
};



