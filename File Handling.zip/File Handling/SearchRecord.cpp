#include "student.h"
#include<fstream>
int main()
{ 
    Student S;
    fstream F;
    int found=0,rollno;
    F.open("student.db",ios::in|ios::binary);
    if(F.bad())
    { 
	    cout<<"File Not Found !!!";
	}   
    else
    {
        cout<<"Enter Student's Roll No. You Want to Search : "; 
        cin>>rollno;
  
        while(!F.eof())
        {
  	        F.read((char*)&S,sizeof(S));
  	        if(F.eof()) break;
  	        found=S.search(rollno);
  	        if(found)
  	        { 
	            break;
	        }
        }
        if(!found)
        { 
		    cout<<"Student Not Found !!!";
        }
	}
    F.close();	   	 
}



