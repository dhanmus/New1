#include "student.h"
#include<fstream>
int main()
{ 
    Student S;
    fstream F;
    F.open("student.db",ios::in|ios::binary);
    if(F.bad())
    { 
        cout<<"File Not Found !!!";
    }
    else
    {  
	    while(!F.eof())
        {
  	        F.read((char*)&S,sizeof(S));
  	        if(F.eof()) break;
  	        S.putStudent();
        }
	}
    F.close();	   	 
}

