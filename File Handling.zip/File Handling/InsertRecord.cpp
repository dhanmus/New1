#include "student.h"
#include<fstream>
int main()
{ 
    Student S;
    fstream F;
    F.open("student.db",ios::out|ios::app|ios::binary);
    char ch;
    do
    {
	    S.getStudent();
        F.write((char*)&S,sizeof(S));
        cout<<"Add More Students : ";
        cin>>ch;
    }  
	while(ch=='Y'|| ch=='y');
    F.close();
}
